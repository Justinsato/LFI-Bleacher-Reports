# LFI React Dashboard

Modular real estate investment dashboard built with React and Material UI.

## 🚀 Dashboards Included
- Portfolio Overview
- Rent Roll Forecast
- Compliance Tracker
- Maintenance
- Accounts Payable / Receivable
- CapEx
- Vacancy & Turnover

## 📂 Folder Structure
```
/src
  /modules        - Dashboard components
  /components     - Shared UI (e.g., filter bar)
AppRoutes.jsx     - All routes defined here
/public/.bleacher - JSON data files
```

## 🛠️ Local Setup
```bash
npm install
npm run start
```

## 📦 Static Serve
```bash
npm run build
bash start-static-server.sh
```
