#!/bin/bash
# Serve the built dashboard locally

if ! command -v serve &> /dev/null
then
    echo "Installing 'serve' globally..."
    npm install -g serve
fi

echo "Serving the build on http://localhost:3000"
serve -s build
