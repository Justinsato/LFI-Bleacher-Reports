import React from "react";

const DashboardFilterBar = ({ onFilterChange = () => {} }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
      <select onChange={(e) => onFilterChange({ property: e.target.value })} className="border p-2 rounded">
        <option value="All">All Properties</option>
        <option value="1230 La Playa Street">1230 La Playa Street</option>
      </select>

      <select onChange={(e) => onFilterChange({ client: e.target.value })} className="border p-2 rounded">
        <option value="All">All Clients</option>
        <option value="Mosser">Mosser</option>
      </select>

      <select onChange={(e) => onFilterChange({ unitType: e.target.value })} className="border p-2 rounded">
        <option value="All">All Unit Types</option>
        <option value="Studio">Studio</option>
      </select>

      <button className="bg-blue-600 text-white rounded px-4 py-2">Go</button>
    </div>
  );
};

export default DashboardFilterBar;
