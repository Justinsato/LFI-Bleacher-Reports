import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import RentForecastDashboard from "./modules/RentRollForecastDashboard";
import ComplianceDashboard from "./modules/ComplianceDashboard";
import PortfolioOverview from "./modules/PortfolioOverview";
import VacancyDashboard from "./modules/VacancyDashboard";
import AccountsPayableDashboard from "./modules/AccountsPayableDashboard";
import AccountsReceivableDashboard from "./modules/AccountsReceivableDashboard";
import MaintenanceDashboard from "./modules/MaintenanceDashboard";
import CapexDashboard from "./modules/CapexDashboard";
import Homepage from "./modules/Homepage";

const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/forecast" element={<RentForecastDashboard />} />
        <Route path="/compliance" element={<ComplianceDashboard />} />
        <Route path="/portfolio" element={<PortfolioOverview />} />
        <Route path="/vacancy" element={<VacancyDashboard />} />
        <Route path="/ap" element={<AccountsPayableDashboard />} />
        <Route path="/ar" element={<AccountsReceivableDashboard />} />
        <Route path="/maintenance" element={<MaintenanceDashboard />} />
        <Route path="/capex" element={<CapexDashboard />} />
      </Routes>
    </Router>
  );
};

export default AppRoutes;
