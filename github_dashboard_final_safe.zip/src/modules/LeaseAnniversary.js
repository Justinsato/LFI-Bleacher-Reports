import { Box, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";


const leaseData = [
  { property: "Valencia Gardens", unit: "A102", moveInDate: "2021-06-15", currentRent: 1895, cpiRate: 0.029 },
  { property: "Mission Plaza", unit: "B307", moveInDate: "2022-06-05", currentRent: 2250, cpiRate: 0.031 },
  { property: "Castro Flats", unit: "C210", moveInDate: "2023-06-12", currentRent: 2440, cpiRate: 0.028 }
];

const LeaseAnniversary = () => {
  return (
    <Box p={3}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Lease Anniversary
      </Typography>

      <Paper>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Property</TableCell>
              <TableCell>Unit</TableCell>
              <TableCell>Move-In Date</TableCell>
              <TableCell>Current Rent</TableCell>
              <TableCell>Approved CPI %</TableCell>
              <TableCell>Projected New Rent</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {leaseData.map((row, i) => {
              const newRent = row.currentRent * (1 + row.cpiRate);
              return (
                <TableRow key={i}>
                  <TableCell>{row.property}</TableCell>
                  <TableCell>{row.unit}</TableCell>
                  <TableCell>{row.moveInDate}</TableCell>
                  <TableCell>${row.currentRent.toLocaleString()}</TableCell>
                  <TableCell>{(row.cpiRate * 100).toFixed(2)}%</TableCell>
                  <TableCell>${Math.round(newRent).toLocaleString()}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default LeaseAnniversary;