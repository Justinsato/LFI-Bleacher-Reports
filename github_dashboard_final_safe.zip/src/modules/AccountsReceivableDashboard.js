import { Box, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";


const arData = [
  { resident: "Maria L.", unit: "A101", property: "Valencia Gardens", balance: 1295, daysLate: 12 },
  { resident: "D. Chang", unit: "B203", property: "Mission Plaza", balance: 650, daysLate: 5 },
  { resident: "J. Ortega", unit: "C309", property: "Castro Flats", balance: 0, daysLate: 0 }
];

const AccountsReceivable = () => {
  return (
    <Box p={3}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Accounts Receivable
      </Typography>

      <Paper>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Resident</TableCell>
              <TableCell>Unit</TableCell>
              <TableCell>Property</TableCell>
              <TableCell>Balance</TableCell>
              <TableCell>Days Late</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {arData.map((row, i) => (
              <TableRow key={i}>
                <TableCell>{row.resident}</TableCell>
                <TableCell>{row.unit}</TableCell>
                <TableCell>{row.property}</TableCell>
                <TableCell>${row.balance.toLocaleString()}</TableCell>
                <TableCell>{row.daysLate}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default AccountsReceivable;