import { Box, Card, CardContent, Grid, Typography } from "@mui/material";


const mockData = {
  totalAUM: 152340000,
  totalUnits: 482,
  avgRent: 2325,
  avgNOI: 985,
  totalComplaints: 42,
  vacantReady: 18,
  vacantNotReady: 9,
  avgTurnCost: 3765,
  avgDaysOnMarket: 28,
  avgPctIncrease: 3.4,
  avgDaysOpen: 41
};

const kpiStyle = {
  fontWeight: "bold",
  fontSize: "1.2rem",
};

const PortfolioOverview = () => {
  return (
    <Box p={3}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Portfolio Overview
      </Typography>

      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>AUM</Typography>
            <Typography style={kpiStyle}>${mockData.totalAUM.toLocaleString()}</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Total Units</Typography>
            <Typography style={kpiStyle}>{mockData.totalUnits}</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Avg Rent</Typography>
            <Typography style={kpiStyle}>${mockData.avgRent.toLocaleString()}</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Avg NOI/Unit</Typography>
            <Typography style={kpiStyle}>${mockData.avgNOI}</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Vacant Ready</Typography>
            <Typography style={kpiStyle}>{mockData.vacantReady}</Typography>
            <Typography variant="caption">Avg Days: {mockData.avgDaysOnMarket}</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Vacant Not Ready</Typography>
            <Typography style={kpiStyle}>{mockData.vacantNotReady}</Typography>
            <Typography variant="caption">Avg Turn Cost: ${mockData.avgTurnCost}</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Avg % Increase</Typography>
            <Typography style={kpiStyle}>{mockData.avgPctIncrease}%</Typography>
          </CardContent></Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card><CardContent>
            <Typography>Open Complaints</Typography>
            <Typography style={kpiStyle}>{mockData.totalComplaints}</Typography>
            <Typography variant="caption">Avg Days Open: {mockData.avgDaysOpen}</Typography>
          </CardContent></Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default PortfolioOverview;