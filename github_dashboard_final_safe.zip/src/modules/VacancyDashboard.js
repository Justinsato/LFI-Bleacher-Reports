import { Box, Grid, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";


const vacantReadyUnits = [
  { property: "Valencia Gardens", unit: "A101", makeReadyDate: "2024-03-01", daysOnMarket: 27, proformaRent: 2150 },
  { property: "Mission Plaza", unit: "B202", makeReadyDate: "2024-02-20", daysOnMarket: 35, proformaRent: 2250 }
];

const vacantNotReadyUnits = [
  { property: "Castro Flats", unit: "C110", renoCost: 7300, lastRent: 1895, proformaRent: 2425 },
  { property: "Sunset Towers", unit: "D405", renoCost: 5600, lastRent: 1750, proformaRent: 2200 }
];

const VacancyAnalysis = () => {
  return (
    <Box p={3}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Vacancy Analysis
      </Typography>

      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Typography variant="h6">Vacant Ready Units</Typography>
          <Paper>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Property</TableCell>
                  <TableCell>Unit</TableCell>
                  <TableCell>Make Ready Date</TableCell>
                  <TableCell>Days on Market</TableCell>
                  <TableCell>Proforma Rent</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {vacantReadyUnits.map((unit, i) => (
                  <TableRow key={i}>
                    <TableCell>{unit.property}</TableCell>
                    <TableCell>{unit.unit}</TableCell>
                    <TableCell>{unit.makeReadyDate}</TableCell>
                    <TableCell>{unit.daysOnMarket}</TableCell>
                    <TableCell>${unit.proformaRent.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Typography variant="h6">Vacant Not Ready Units</Typography>
          <Paper>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Property</TableCell>
                  <TableCell>Unit</TableCell>
                  <TableCell>Last Rent</TableCell>
                  <TableCell>Proforma Rent</TableCell>
                  <TableCell>Reno Cost</TableCell>
                  <TableCell>Annual Recapture ROI</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {vacantNotReadyUnits.map((unit, i) => {
                  const rentDiff = unit.proformaRent - unit.lastRent;
                  const annualGain = rentDiff * 12;
                  const roi = unit.renoCost > 0 ? (annualGain / unit.renoCost) * 100 : 0;
                  return (
                    <TableRow key={i}>
                      <TableCell>{unit.property}</TableCell>
                      <TableCell>{unit.unit}</TableCell>
                      <TableCell>${unit.lastRent.toLocaleString()}</TableCell>
                      <TableCell>${unit.proformaRent.toLocaleString()}</TableCell>
                      <TableCell>${unit.renoCost.toLocaleString()}</TableCell>
                      <TableCell>{roi.toFixed(1)}%</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default VacancyAnalysis;