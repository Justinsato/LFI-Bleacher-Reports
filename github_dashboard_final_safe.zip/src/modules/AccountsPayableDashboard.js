import { Box, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";


const apData = [
  { vendor: "ABC Plumbing", property: "Valencia Gardens", amountDue: 2130, dueDays: 14 },
  { vendor: "Green Janitorial", property: "Mission Plaza", amountDue: 885, dueDays: 32 },
  { vendor: "Sun HVAC", property: "Castro Flats", amountDue: 1420, dueDays: 5 }
];

const AccountsPayable = () => {
  return (
    <Box p={3}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Accounts Payable
      </Typography>

      <Paper>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Vendor</TableCell>
              <TableCell>Property</TableCell>
              <TableCell>Amount Due</TableCell>
              <TableCell>Days Outstanding</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {apData.map((row, i) => (
              <TableRow key={i}>
                <TableCell>{row.vendor}</TableCell>
                <TableCell>{row.property}</TableCell>
                <TableCell>${row.amountDue.toLocaleString()}</TableCell>
                <TableCell>{row.dueDays}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default AccountsPayable;