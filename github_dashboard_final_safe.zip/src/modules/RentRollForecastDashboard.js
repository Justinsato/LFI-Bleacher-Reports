import { Button, Card, CardContent, Select } from "@mui/material";


const RentForecastDashboard = () => {
  const [data, setData] = useState([]);
  const [properties, setProperties] = useState([]);
  const [selectedProperty, setSelectedProperty] = useState("All Properties");

  useEffect(() => {
    fetch("/.bleacher/rentroll_forecast_summary.json")
      .then((res) => res.json())
      .then((json) => {
        setData(json);
        const uniqueProperties = [
          "All Properties",
          ...new Set(json.map((item) => item["Property Name"]))
        ];
        setProperties(uniqueProperties);
      });
  }, []);

  const filteredData = selectedProperty === "All Properties"
    ? data
    : data.filter(d => d["Property Name"] === selectedProperty);

  const groupedData = filteredData.reduce((acc, row) => {
    const date = row["Forecast Date"];
    if (!acc[date]) acc[date] = 0;
    acc[date] += row["Forecasted Rent"];
    return acc;
  }, {});

  const chartData = Object.entries(groupedData).map(([date, rent]) => ({
    date,
    rent: parseFloat(rent.toFixed(2)),
  }));

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Rent Forecast Dashboard</h1>

      <div className="flex justify-between items-center mb-4">
        <div>
          <label className="mr-2 font-medium">Select Property:</label>
          <select
            value={selectedProperty}
            onChange={(e) => setSelectedProperty(e.target.value)}
            className="border rounded px-2 py-1"
          >
            {properties.map((prop) => (
              <option key={prop} value={prop}>{prop}</option>
            ))}
          </select>
        </div>
      </div>

      <Card>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis tickFormatter={(val) => `$${val.toLocaleString()}`} />
              <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
              <Legend />
              <Line type="monotone" dataKey="rent" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export default RentForecastDashboard;