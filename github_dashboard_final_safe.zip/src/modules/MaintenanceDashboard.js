import { Box, Button, Grid, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";


const MaintenanceDashboard = ({ expenseData = [], budgetData = [] }) => {
  const [selectedProperty, setSelectedProperty] = React.useState("All");

  const properties = Array.from(new Set(expenseData.map(e => e.property)));

  const filteredExpenses = selectedProperty === "All"
    ? expenseData
    : expenseData.filter(e => e.property === selectedProperty);

  const filteredBudget = selectedProperty === "All"
    ? budgetData
    : budgetData.filter(b => b.property === selectedProperty);

  const monthlyTrend = filteredExpenses.reduce((acc, curr) => {
    const key = `${curr.month}-${curr.category}`;
    acc[key] = acc[key] || { month: curr.month, category: curr.category, actual: 0, budget: 0 };
    acc[key].actual += curr.amount;
    return acc;
  }, {});

  filteredBudget.forEach(b => {
    const key = `${b.month}-${b.category}`;
    if (!monthlyTrend[key]) {
      monthlyTrend[key] = { month: b.month, category: b.category, actual: 0, budget: 0 };
    }
    monthlyTrend[key].budget += b.amount;
  });

  const trendArray = Object.values(monthlyTrend);

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Maintenance & Expense Monitoring
      </Typography>

      <Box my={2}>
        <FormControl fullWidth>
          <InputLabel>Select Property</InputLabel>
          <Select value={selectedProperty} label="Select Property" onChange={e => setSelectedProperty(e.target.value)}>
            <MenuItem value="All">All Properties</MenuItem>
            {properties.map(p => (
              <MenuItem key={p} value={p}>{p}</MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      <Grid container spacing={2} mb={4}>
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Monthly Expense Trends
          </Typography>
          <Box height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendArray}>
                <XAxis dataKey="month" />
                <YAxis tickFormatter={v => `$${v.toLocaleString()}`} />
                <Tooltip formatter={v => `$${v.toLocaleString()}`} />
                <Legend />
                <Line type="monotone" dataKey="actual" name="Actual" stroke="#1976d2" />
                <Line type="monotone" dataKey="budget" name="Budget" stroke="#9c27b0" strokeDasharray="4 2" />
              </LineChart>
            </ResponsiveContainer>
          </Box>
        </Grid>
      </Grid>

      <Typography variant="h6" fontWeight="bold" gutterBottom>
        Expense Breakdown
      </Typography>
      <TableContainer component={Paper} sx={{ mb: 3 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Month</TableCell>
              <TableCell>Category</TableCell>
              <TableCell align="right">Actual</TableCell>
              <TableCell align="right">Budget</TableCell>
              <TableCell align="right">Variance</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {trendArray.map((row, idx) => (
              <TableRow key={idx}>
                <TableCell>{row.month}</TableCell>
                <TableCell>{row.category}</TableCell>
                <TableCell align="right">${row.actual.toLocaleString()}</TableCell>
                <TableCell align="right">${row.budget.toLocaleString()}</TableCell>
                <TableCell align="right">${(row.actual - row.budget).toLocaleString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Button
        variant="outlined"
        onClick={() => {
          const headers = ['Month', 'Category', 'Actual', 'Budget', 'Variance'];
          const rows = trendArray.map(r => [
            r.month, r.category, r.actual, r.budget, r.actual - r.budget
          ]);
          const csv = [headers, ...rows].map(r => r.join(",")).join("\n");

          const blob = new Blob([csv], { type: "text/csv" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "MaintenanceExpenseDetail.csv";
          a.click();
        }}
      >
        Export to CSV
      </Button>
    </Box>
  );
};

export default MaintenanceDashboard;