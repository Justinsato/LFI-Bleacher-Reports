import { Box, Paper, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material";


const capexProjects = [
  { projectName: "HVAC Retrofit - Valencia", property: "Valencia Gardens", budget: 42000, actual: 38650 },
  { projectName: "Roofing - Mission", property: "Mission Plaza", budget: 67000, actual: 71200 },
  { projectName: "Elevator Modernization", property: "Castro Flats", budget: 88000, actual: 87950 }
];

const CapexDashboard = () => {
  return (
    <Box p={3}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        CapEx Dashboard
      </Typography>

      <Paper>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Project</TableCell>
              <TableCell>Property</TableCell>
              <TableCell>Budget</TableCell>
              <TableCell>Actual</TableCell>
              <TableCell>Variance</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {capexProjects.map((row, i) => {
              const variance = row.actual - row.budget;
              return (
                <TableRow key={i}>
                  <TableCell>{row.projectName}</TableCell>
                  <TableCell>{row.property}</TableCell>
                  <TableCell>${row.budget.toLocaleString()}</TableCell>
                  <TableCell>${row.actual.toLocaleString()}</TableCell>
                  <TableCell style={{ color: variance > 0 ? "red" : "green" }}>
                    {variance >= 0 ? "+" : "-"}${Math.abs(variance).toLocaleString()}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Paper>
    </Box>
  );
};

export default CapexDashboard;