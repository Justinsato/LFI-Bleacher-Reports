import { Box, Card, CardContent, Typography } from "@mui/material";


const Homepage = () => {
  return (
    <Box p={4}>
      <Typography variant="h3" fontWeight="bold" gutterBottom>
        Welcome to The Left Field Bleachers
      </Typography>
      <Typography variant="body1" mb={3}>
        Your interactive real estate performance cockpit. Explore financials, leasing, compliance, and forecast metrics across your San Francisco multifamily portfolio.
      </Typography>

      <Card variant="outlined">
        <CardContent>
          <Typography variant="h6">Modules Include:</Typography>
          <ul>
            <li>Portfolio AUM & Map</li>
            <li>Lease Anniversary Tracker</li>
            <li>Rent Roll Forecast</li>
            <li>Vacancy Analysis</li>
            <li>Compliance & Complaints</li>
            <li>Maintenance & CapEx</li>
            <li>AR & AP Aging</li>
          </ul>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Homepage;