import { Card, CardContent } from "@mui/material";

import React, { useEffect, useState } from "react";
import DashboardFilterBar from "../components/DashboardFilterBar";


const ComplianceDashboard = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("/.bleacher/complaints.json") // Replace with actual API or data path
      .then((res) => res.json())
      .then(setData);
  }, []);

  const flagged = data.filter(item => {
    return (
      item.status !== "Closed" &&
      (item.type === "Mold" || item.type === "Rodent" || item.type === "Water Leak")
    );
  });

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Compliance Tracker</h1>
      <DashboardFilterBar onFilterChange={(filters) => console.log(filters)} />
      <Card>
        <CardContent>
          <table className="w-full table-auto">
            <thead>
              <tr>
                <th className="text-left px-2 py-1">Property</th>
                <th className="text-left px-2 py-1">Unit</th>
                <th className="text-left px-2 py-1">Type</th>
                <th className="text-left px-2 py-1">Status</th>
                <th className="text-left px-2 py-1">Date</th>
              </tr>
            </thead>
            <tbody>
              {flagged.map((row, index) => (
                <tr key={index} className="border-t">
                  <td className="px-2 py-1">{row.property_name}</td>
                  <td className="px-2 py-1">{row.unit}</td>
                  <td className="px-2 py-1">{row.type}</td>
                  <td className="px-2 py-1">{row.status}</td>
                  <td className="px-2 py-1">{row.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};

export default ComplianceDashboard;